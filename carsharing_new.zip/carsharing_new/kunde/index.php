<?php
require __DIR__ . "/../connect/connect.php";


$stmt = $pdo->prepare(
    "SELECT * FROM kunde"
);

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kunde</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<?php include('../header.php'); ?>
<h1>Kunde</h1>
<table class="table table-striped">
    <thead>
    <tr>
        <th>Kunde ID</th>
        <th>Vorname</th>
        <th>Nachname</th>
        <th>EMail</th>
        <th>Telefonnummer</th>
        <th>Bearbeiten</th>
        <th>Löschen</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['vorname']; ?></td>
            <td><?php echo $row['nachname']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['telefon']; ?></td>
            <td><a href="./update.php?id=<?php echo $row['id']; ?>" >Bearbeiten</a></td>
            <td><a href="./delete.php?id=<?php echo $row['id']; ?>" >Löschen</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php include('../footer.php'); ?>
<a href="insert.php" >Kunde hinzufügen</a>
<a href="../index.php">Zur Übersicht</a>
</body>
</html>