<?php
require __DIR__ . "/../connect/connect.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $vorname = $_POST['vorname'];
    $nachname = $_POST['nachname'];
    $email = $_POST['email'];
    $telefon = $_POST['telefon'];

    
    $stmt = $pdo->prepare("INSERT INTO kunde (id, vorname, nachname, email, telefon) VALUES (:id, :vorname, :nachname, :email, :telefon)");
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':vorname', $vorname);
    $stmt->bindValue(':nachname', $nachname);
    $stmt->bindValue(':email', $email);
    $stmt->bindValue(':telefon', $telefon);

    $stmt->execute();

    header('location:./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kunde</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>

<h1>Neuen Kunde hinzufügen</h1>

 <form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required>
        
        <label for="vorname">Vorname:</label>
        <input type="text" id="vorname" name="vorname" required?>

        <label for="nachname">Nachname:</label>
        <input type="text" id="nachname" name="nachname" required?>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required?>

        <label for="telefon">Telefonnummer:</label>
        <input type="text" id="telefon" name="telefon" required?>


        <button type="submit">Kunde hinzufügen</button>
    </form>
</div>

<a href="index.php">Zurück</a>
</body>
</html>