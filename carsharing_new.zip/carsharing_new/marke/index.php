    <?php
    require __DIR__ . "/../connect/connect.php";

    //Aufruf der Methode prepare() auf das Objekt $pdo
    $stmt = $pdo->prepare("SELECT * FROM marke;");

    //Ausführen des SQL-Statements von oben (SELECT ...)
    $stmt->execute();

    //Holen der Datensätze (nur als key/value-Paare = assoziatives Array)
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Marke</title>
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    </head>
    <body>
    <?php include('../header.php'); ?>
        <h1>Marke</h1>
        <table class="table table-striped">
            <thead>
            <tr>
            <th>Marke ID</th>
            <th>Name</th>
            <th>Bearbeiten</th>
            <th>Löschen</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($result as $row): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><a href="delete.php?id=<?= $row['id'] ?>">Löschen</a></td>
                <td><a href="update.php?id=<?= $row['id'] ?>">Bearbeiten</a></td>
                </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php include('../footer.php'); ?>
    <a href="insert.php">Marke anlegen</a>
    <a href="../index.php">Zur Übersicht</a>
    </body>
    </html>