<?php
require __DIR__ . "/../connect/connect.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $name = $_POST['name'];

    //Aufruf der Methode prepare() auf das Objekt $pdo
    $stmt = $pdo->prepare("INSERT INTO marke (id, `name`) VALUES (:id, :name)");

    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':name', $name);

    $stmt->execute();

    header('location:./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marke anlegen</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<h1>Neue Marke hinzufügen</h1>
     <form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required>
        
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>


        <button type="submit">Marke hinzufügen</button>
    </form>
    <a href="index.php">Zurück</a>
</body>
</html>