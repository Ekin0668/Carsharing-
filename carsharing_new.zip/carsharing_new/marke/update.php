<?php
require __DIR__ . "/../connect/connect.php";

//Vorbefüllen der Input-Felder
if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];

    $stmt = $pdo->prepare("SELECT * FROM marke WHERE id=:id");
    $stmt->bindParam(":id", $id);
    $stmt->execute();
    
    $kunde = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $name = $_POST['name'];
    
        // Vorbereitete SQL-Anweisung ausführen
        $stmt = $pdo->prepare("UPDATE marke SET `name` = :name WHERE id = :id");
    
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':name', $name);

        $stmt->execute();
    
        header('location:./index.php');
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marke ÄNDERN</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<h1>Marke ändern</h1>

<form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required value="<?php echo $kunde['id']; ?>">

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required value="<?php echo $kunde['name']; ?>">

        <button type="submit">Marke ändern</button>
    </form>

    <a href="index.php">Zurück</a>
</body>
</html>