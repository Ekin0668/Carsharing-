<?php

try {
    $pdo = new PDO('mysql:host=localhost;dbname=carsharing','root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $_) {
    echo "Exception on connect!";
    exit;
}
