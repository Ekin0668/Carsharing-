<?php
require __DIR__ . "/../connect/connect.php";

$stmt = $pdo->prepare('SELECT * FROM modell');
$stmt->execute();
$result_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $modell_id = $_POST['modell_id'];
    $kennzeichen = $_POST['kennzeichen'];

    $stmt = $pdo->prepare("INSERT INTO automobil (id, modell_id, kennzeichen) VALUES (:id, :modell_id, :kennzeichen)");

    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':modell_id', $modell_id);
    $stmt->bindValue(':kennzeichen', $kennzeichen);

    $stmt->execute();

    header('location:./index.php');
}
?>


<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automobil hinzufügen</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<h1>Neues Automobil hinzufügen</h1>

<form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required>
        
        <label for="modell_id" class="form-label">Modell</label>
            <select class="form-container" id="modell_id" name="modell_id" required>
                <option value="">Bitte wählen</option>
                <?php foreach ($result_customers as $result): ?>
                    <option value="<?php echo $result['id'] ?>"><?php echo $result['name']?></option>
                <?php endforeach; ?>
            </select>
        
        <label for="kennzeichen">Kennzeichen:</label>
        <input type="text" id="kennzeichen" name="kennzeichen" required?>


        <button type="submit">Vermietung hinzufügen</button>
    </form>
<a href="index.php">Zurück</a>
<a href="../index.php">Zur Übersicht</a>
</body>
</html>