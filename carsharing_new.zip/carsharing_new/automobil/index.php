<?php
require __DIR__ . "/../connect/connect.php";

// execute prepare with SQL-statement
$stmt = $pdo->prepare("SELECT
        a.id as id,
        a.kennzeichen, 
        a.modell_id
    FROM automobil a
    LEFT JOIN modell m ON m.id = a.modell_id;"
);

// execute SQL-statement
$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automobil</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<?php include('../header.php'); ?>
<h1>Automobil</h1>
<table class="table table-striped">
    <thead>
    <tr>
        <th>Automobil ID</th>
        <th>Modell ID</th>
        <th>Kennzeichen</th>
        <th>Bearbeiten</th>
        <th>Löschen</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['modell_id']; ?></td>
            <td><?php echo $row['kennzeichen']; ?></td>
            <td><a href="./update.php?id=<?php echo $row['id']; ?>">Bearbeiten</a></td>
            <td><a href="./delete.php?id=<?php echo $row['id']; ?>">Löschen</a></td>
        </tr>
    <?php endforeach; ?>    
    </tbody>
</table>
<?php include('../footer.php'); ?>
<a href="insert.php">Automobil hinzufügen</a>
<a href="../index.php">Zur Übersicht</a>
</body>
</html>