<?php
require __DIR__ . "/../connect/connect.php";

$stmt = $pdo->prepare('SELECT * FROM modell');
$stmt->execute();
$result_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];

    $stmt = $pdo->prepare("SELECT * FROM automobil WHERE id=:id");
    $stmt->bindParam(":id", $id);
    $stmt->execute();
    $automobil = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $modell_id = $_POST['modell_id'];
        $kennzeichen = $_POST['kennzeichen'];

        $stmt = $pdo->prepare("UPDATE automobil SET modell_id = :modell_id, kennzeichen = :kennzeichen WHERE id = :id");
    
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':modell_id', $modell_id);
        $stmt->bindValue(':kennzeichen', $kennzeichen);

        $stmt->execute();
    
        header('location:./index.php');
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automobil ÄNDERN</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<h1>Automobil ändern</h1>

<form action="" method="POST">

<label for="id">ID:</label>
<input type="number" id="id" name="id" required value="<?php echo $automobil['id']; ?>">

<label for="modell_id" class="form-label">Modell</label>
    <select class="form-container" id="modell_id" name="modell_id" required value="<?php echo $result_customers['modell_id']; ?>">
        <option value="">Bitte wählen</option>
        <?php foreach ($result_customers as $result): ?>
            <option value="<?php echo $result['id'] ?>"><?php echo  $result['name']?></option>
        <?php endforeach; ?>
    </select>


<label for="kennzeichen">Kennzeichen</label>
<input type="text" id="kennzeichen" name="kennzeichen" required value="<?php echo $automobil['kennzeichen']; ?>">

<button type="submit">Automobil ändern</button>
</form>

<a href="index.php">Zurück</a>
</body>
</html>