<?php
require __DIR__ . '/../DBConnect/DBconnect.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    // Aktuelles Modell abrufen
    $stmt = $pdo->prepare("SELECT * FROM modell WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $modell = $stmt->fetch(PDO::FETCH_ASSOC);

    // Alle Marken holen für Dropdown
    $stmt = $pdo->prepare("SELECT * FROM marke");
    $stmt->execute();
    $marken = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Wenn Formular abgeschickt wurde
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $new_id = $_POST['id'];
        $marke_id = $_POST['marke_id'];
        $name = $_POST['name'];

        $stmt = $pdo->prepare("UPDATE modell SET id = :new_id, marke_id = :marke_id, name = :name WHERE id = :id");
        $stmt->execute([
            ':new_id' => $new_id,
            ':marke_id' => $marke_id,
            ':name' => $name,
            ':id' => $id
        ]);

        header("Location: index.php");
        exit;
    }
} else {
    echo "Keine ID angegeben.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MODELL ÄNDERN</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>

<h1>Modell ändern</h1>

<form method="post">
    <label for="id">ID:</label>
    <input type="number" name="id" id="id" value="<?= $modell['id'] ?>" required>

    <label for="marke_id">Marke:</label>
    <select name="marke_id" id="marke_id" required>
        <option value="">Bitte wählen</option>
        <?php foreach ($marken as $marke): ?>
            <option value="<?= $marke['id'] ?>" <?= $marke['id'] == $modell['marke_id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($marke['name']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="name">Modellname:</label>
    <input type="text" name="name" id="name" value="<?= htmlspecialchars($modell['name']) ?>" required>

    <button type="submit">Speichern</button>
</form>

<a href="index.php">Zurück</a>

</body>
</html>