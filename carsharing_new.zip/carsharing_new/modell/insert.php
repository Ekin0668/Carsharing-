<?php
require __DIR__ . "/../connect/connect.php";

$stmt = $pdo->prepare('SELECT * FROM marke');
$stmt->execute();
$result_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $marken_id = $_POST['marke_id'];
    $name = $_POST['name'];

    
    $stmt = $pdo->prepare("INSERT INTO modell (id, marke_id, `name`) VALUES (:id, :marke_id, :name)");

    $stmt->bindValue(':id', $id,);
    $stmt->bindValue(':marke_id', $marken_id);
    $stmt->bindValue(':name', $name);

    $stmt->execute();

    header('location:./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modell</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>

<h1>Neues Modell hinzufügen</h1>

<form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required>
        
        <label for="marke_id">Marke</label>
            <select id="marke_id" name="marke_id" required>
                <option value="">Bitte wählen</option>
                <?php foreach ($result_customers as $result): ?>
                    <option value="<?php echo $result['id'] ?>"><?php echo $result['name']?></option>
                <?php endforeach; ?>
            </select>
        
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required?>


        <button type="submit">Modell hinzufügen</button>
    </form>
</div>

<a href="index.php">Zurück</a>
</body>
</html>