<?php
require __DIR__ . "/../connect/connect.php";

$stmt = $pdo->prepare(
    "SELECT
        mo.id as id,
        mo.marke_id,
        mo.name 
    FROM modell mo
    LEFT JOIN marke ma ON mo.marke_id = ma.id;"
);

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modell</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<h1>Modell</h1>
<?php include('../header.php'); ?>
<table class="table table-striped">
    <thead>
    <tr>
        <th>Modell ID</th>
        <th>Marke ID</th>
        <th>Name</th>
        <th>Bearbeiten</th>
        <th>Löschen</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['marke_id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><a href="./update.php?id=<?php echo $row['id']; ?>">Bearbeiten</a></td>
            <td><a href="./delete.php?id=<?php echo $row['id']; ?>">Löschen</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php include('../footer.php'); ?>
<a href="insert.php">Modell hinzufügen</a>
<a href="../index.php">Zur Übersicht</a>
</body>
</html>