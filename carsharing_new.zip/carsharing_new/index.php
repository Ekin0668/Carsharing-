<?php
// Kein PHP-Code notwendig, außer includes
?>

<!doctype html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">
    <title>Carsharing - Übersicht</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<?php include('header.php'); ?>

<div class="container mt-5">
    <h1 class="mb-4">Carsharing Übersicht</h1>

    <div class="row g-3">
        <div class="col-12 col-md-6 col-lg-4">
            <a href="automobil" class="btn btn-primary w-100">Automobil</a>
        </div>
        <div class="col-12 col-md-6 col-lg-4">
            <a href="kunde" class="btn btn-primary w-100">Kunde</a>
        </div>
        <div class="col-12 col-md-6 col-lg-4">
            <a href="marke" class="btn btn-primary w-100">Marke</a>
        </div>
        <div class="col-12 col-md-6 col-lg-4">
            <a href="modell" class="btn btn-primary w-100">Modell</a>
        </div>
        <div class="col-12 col-md-6 col-lg-4">
            <a href="vermietung" class="btn btn-primary w-100">Vermietung</a>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>