<?php
// Stellt eine Verbindung zur Datenbank her
require __DIR__ . "/../connect/connect.php";

$stmt = $pdo->prepare('SELECT * FROM kunde');
$stmt->execute();
$result_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare('SELECT * FROM automobil');
$stmt->execute();
$result_auto = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($_GET['id'])) {
    $id = (int) $_GET['id']; 

    $stmt = $pdo->prepare("SELECT * FROM vermietung WHERE id=:id");
    $stmt->bindParam(":id", $id);
    $stmt->execute();
    $vermietung = $stmt->fetch(PDO::FETCH_ASSOC); 

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $kunden_id = $_POST['kunden_id'];
        $automobil_id = $_POST['automobil_id'];
        $startdatum = $_POST['startdatum'];
        $enddatum = $_POST['enddatum'];
        $startkilometer = $_POST['startkilometer'];
        $endkilometer = $_POST['endkilometer'];
        $preis_pro_km = $_POST['preis_pro_km'];
        $preis_pro_tag = $_POST['preis_pro_tag'];

        // Bereitet ein SQL-Statement vor, um einen bestehenden Eintrag in der Tabelle "vermietung" zu aktualisieren.
        $stmt2 = $pdo->prepare("UPDATE vermietung SET kunde_id = :kunde_id, automobil_id = :automobil_id,
        startdatum = :startdatum, enddatum = :enddatum, startkilometer = :startkilometer, endkilometer = :endkilometer,
        preis_pro_km = :preis_pro_km, preis_pro_tag = :preis_pro_tag WHERE id = :id");

        // Bindet die Werte an die SQL-Anweisung
        $stmt2->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt2->bindParam(':kunde_id', $kunden_id, PDO::PARAM_INT);
        $stmt2->bindParam(':automobil_id', $automobil_id, PDO::PARAM_INT);
        $stmt2->bindParam(':startdatum', $startdatum, PDO::PARAM_STR);
        $stmt2->bindParam(':enddatum', $enddatum, PDO::PARAM_STR);
        $stmt2->bindParam(':startkilometer', $startkilometer, PDO::PARAM_INT);
        $stmt2->bindParam(':endkilometer', $endkilometer, PDO::PARAM_INT);
        $stmt2->bindParam(':preis_pro_km', $preis_pro_km, PDO::PARAM_INT);
        $stmt2->bindParam(':preis_pro_tag', $preis_pro_tag, PDO::PARAM_INT);

        $stmt2->execute();
        
        header("LOCATION: ./index.php");
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vermietung ÄNDERN</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<h1>Vermietung ändern</h1>
<form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required value="<?php echo $vermietung['id']; ?>" readonly>
        <br><br>

        <label for="kunde_id" class="form-label">Kunde</label>
        <select class="form-container" id="kunde_id" name="kunden_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($result_customers as $result): ?>
                <option value="<?php echo $result['id']; ?>" 
                    <?php echo ($result['id'] == $vermietung['kunde_id']) ? 'selected' : ''; ?>>
                    <?php echo $result['nachname']. " " . $result['vorname']; ?>
                </option>
            <?php endforeach; ?>
        </select>

       
        <label for="automobil_id" >Automobil</label>
        <select id="automobil_id" name="automobil_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($result_auto as $result): ?>
                <option value="<?php echo $result['id']; ?>" 
                    <?php echo ($result['id'] == $vermietung['automobil_id']) ? 'selected' : ''; ?>>
                    <?php echo $result['kennzeichen']; ?>
                </option>
            <?php endforeach; ?>
        </select>

        
        <label for="startdatum">Startdatum:</label>
        <input type="date" id="startdatum" name="startdatum" required value="<?php echo $vermietung['startdatum']; ?>">
        <br><br>
        
        <label for="enddatum">Enddatum:</label>
        <input type="date" id="enddatum" name="enddatum" required value="<?php echo $vermietung['enddatum']; ?>">
        <br><br>
        
        <label for="startkilometer">Startkilometer:</label>
        <input type="number" id="startkilometer" name="startkilometer" required value="<?php echo $vermietung['startkilometer']; ?>">
        <br><br>
        
        <label for="endkilometer">Endkilometer:</label>
        <input type="number" id="endkilometer" name="endkilometer" required value="<?php echo $vermietung['endkilometer']; ?>">
        <br><br>
        
        <label for="preis_pro_km">Preis pro Kilometer:</label>
        <input type="number" id="preis_pro_km" name="preis_pro_km" required value="<?php echo $vermietung['preis_pro_km']; ?>">
        <br><br>
        
        <label for="preis_pro_tag">Preis pro Tag:</label>
        <input type="number" id="preis_pro_tag" name="preis_pro_tag" required value="<?php echo $vermietung['preis_pro_tag']; ?>">
        <br><br>
        
        <button type="submit">Vermietung ändern</button>
    </form>

<a href="index.php">Zurück</a>

</body>
</html>