<?php
// Stellt eine Verbindung zur Datenbank her
require __DIR__ . "/../connect/connect.php";

$stmt = $pdo->prepare(
    "SELECT
        v.id as id, 
        v.kunde_id, v.automobil_id,
        v.startdatum, v.enddatum, v.startkilometer, v.endkilometer,
        v.preis_pro_km, v.preis_pro_tag,
        a.kennzeichen, a.modell_id,
        k.nachname, k.vorname
    FROM vermietung v
    LEFT JOIN kunde k ON k.id = v.kunde_id
    LEFT JOIN automobil a ON v.automobil_id = a.id;"
);

$stmt->execute();

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vermietung</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<?php include('../header.php'); ?>
<h1>Vermietung</h1>

<table class="table table-striped">
    <thead>
    <tr>
        <th>Vermietung ID</th>
        <th>Kunde ID</th>
        <th>Automobil ID</th>
        <th>Startdatum</th>
        <th>Enddatum</th>
        <th>Startkilometer</th>
        <th>Endkilometer</th>
        <th>Preis pro km</th>
        <th>Preis pro Tag</th>
        <th>Bearbeiten</th>
        <th>Löschen</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['kunde_id']; ?></td>
            <td><?php echo $row['automobil_id']; ?></td>
            <td><?php echo $row['startdatum']; ?></td>
            <td><?php echo $row['enddatum']; ?></td>
            <td><?php echo $row['startkilometer']; ?></td>
            <td><?php echo $row['endkilometer']; ?></td>
            <td><?php echo $row['preis_pro_km']; ?></td>
            <td><?php echo $row['preis_pro_tag']; ?></td>
            
            <td><a href="./update.php?id=<?php echo $row['id']; ?>">Bearbeiten</a></td>
            <td><a href="./delete.php?id=<?php echo $row['id']; ?>">Löschen</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php include('../footer.php'); ?>
<a href="insert.php" >Vermietung hinzufügen</a>
<a href="../index.php">Zur Übersicht</a>

</body>
</html>
