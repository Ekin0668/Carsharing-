<?php
// Stellt eine Verbindung zur Datenbank her
require __DIR__ . "/../connect/connect.php";

$stmt = $pdo->prepare('SELECT * FROM kunde');
$stmt->execute();
$result_customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare('SELECT * FROM automobil');
$stmt->execute();
$result_auto = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $kunden_id = $_POST['kunde_id'];
    $automobil_id = $_POST['automobil_id'];
    $startdatum = $_POST['startdatum'];
    $enddatum = $_POST['enddatum'];
    $startkilometer = $_POST['startkilometer'];
    $endkilometer = $_POST['endkilometer'];
    $preis_pro_km = $_POST['preis_pro_km'];
    $preis_pro_tag = $_POST['preis_pro_tag'];
    
    $stmt = $pdo->prepare("INSERT INTO vermietung (id, kunde_id, automobil_id, startdatum, enddatum, startkilometer, 
    endkilometer, preis_pro_km, preis_pro_tag) VALUES (:id, :kunde_id, :automobil_id, :startdatum, :enddatum, :startkilometer, 
    :endkilometer, :preis_pro_km, :preis_pro_tag)");

    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':kunde_id', $kunden_id);
    $stmt->bindValue(':automobil_id', $automobil_id);
    $stmt->bindValue(':startdatum', $startdatum);
    $stmt->bindValue(':enddatum', $enddatum);
    $stmt->bindValue(':startkilometer', $startkilometer);
    $stmt->bindValue(':endkilometer', $endkilometer);
    $stmt->bindValue(':preis_pro_km', $preis_pro_km);
    $stmt->bindValue(':preis_pro_tag', $preis_pro_tag);

    $stmt->execute();

    header('location:./index.php');
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vermietung</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
<h1>Neue Vermietung hinzufügen</h1>

 <form action="" method="POST">

        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required>
        <br><br>
        
        <label for="kunde_id" >Kunde</label>
        <select  id="kunde_id" name="kunde_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($result_customers as $result): ?>
                <option value="<?php echo $result['id'] ?>"><?php echo $result['nachname']. " " . $result['vorname']?></option>
            <?php endforeach; ?>
        </select>
        
        <label for="automobil_id">Automobil</label>
        <select id="automobil_id" name="automobil_id" required>
            <option value="">Bitte wählen</option>
            <?php foreach ($result_auto as $result): ?>
                <option value="<?php echo $result['id'] ?>"><?php echo $result['kennzeichen']?></option>
            <?php endforeach; ?>
        </select>

        <label for="startdatum">Startdatum:</label>
        <input type="date" id="startdatum" name="startdatum" required>
        <br><br>

        <label for="enddatum">Enddatum:</label>
        <input type="date" id="enddatum" name="enddatum" required>
        <br><br>

        <label for="startkilometer">Startkilometer:</label>
        <input type="number" id="startkilometer" name="startkilometer" required>
        <br><br>

        <label for="endkilometer">Endkilometer:</label>
        <input type="number" id="endkilometer" name="endkilometer" required>
        <br><br>

        <label for="preis_pro_km">Preis pro Kilometer:</label>
        <input type="number" id="preis_pro_km" name="preis_pro_km" required>
        <br><br>

        <label for="preis_pro_tag">Preis pro Tag:</label>
        <input type="number" id="preis_pro_tag" name="preis_pro_tag" required>
        <br><br>

        <button type="submit">Vermietung hinzufügen</button>
    </form>
</div>

<a href="index.php">Zurück</a>

</body>
</html>
